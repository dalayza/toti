var nome = prompt('Por favor insira seu nome: ');

console.log(nome);