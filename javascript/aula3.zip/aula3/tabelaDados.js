var nome = prompt('Por favor insira seu nome: ');

var sobrenome = prompt('Por favor insira seu sobrenome: ');

var idade = prompt('Por favor insira seu idade: ');

console.table(tabela);